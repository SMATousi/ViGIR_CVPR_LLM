These JSON files store the eurosat results after modifying the prompt and using the text embeddings to compute the class name.
